#include<iostream>
#include<fstream>

using namespace std; 

int main(){

int codigos [200][200] {}; 
float pesodis [200][200] {};
string ncliente {8};
string alimentos {5}; 

ifstream archidatos; 
archidatos.open("DATOS.txt"); 
if (!archidatos)
{
    cout << "error al tratar de abrir el archivo" << endl; 
    return 1; 
}

int fila = 0; 
int col = 0; 

    while(archidatos){
        for (int i = 0; i < 2; i++)
        {
            archidatos >> codigos [fila][col]; 
            col++; 
        }
        //fila++; 
        col = 0; 

        for (int i = 0; i < 2; i++)
        {
            archidatos >> pesodis [fila][col]; 
            col++; 
        }
        fila++; 
        col = 0;          
    }

    /*for (int i = 0; i < 2; i++)
    {
        for (int j = 0; j < 2; i++)
        {
            cout << pesodis [i][j] <<"  " << endl; 
        }       
    }*/

    archidatos.close(); 

    ifstream archinombres; 
    archinombres.open("NOMBRES.txt"); 
    if (!archinombres)
    {
        cout << "error al tratar de abrir el archivo" << endl; 
        return 1; 
    }

        for (int i = 0; i < 8; i++)
        {
            archinombres >> ncliente[i]; 
            //cout << ncliente[i]; 
        }
        
        
        for (int i = 0; i < 5; i++)
        {
            archinombres >> alimentos[i];
            //cout << alimentos[i];  
        }

//punto 1:

    cout << "armando listado para los clientes con productos que pesen mas de 13000Kg ..." << endl;
        
    int dim = 13000;   
    int cli[dim]; 
    int i, j, k, l;
    float kilogramos[5] {0};


for(i = 0; i < 8; i++){ //nombre i
//for(j = 0; j < 5; j++){ //posicion del vector con respecto a el tipo de producto
for(k = 0; k < 120; k++){
if(i == codigos[k][0]){ //si el nombre coincide con el numero del nombre
//peso[j] += pesodistancia [k][1];
kilogramos[codigos[k][1]] += pesodis [k][0];
//cout << peso[j] << endl;
//cout << peso[codigos[k][1]] << " ";
}
}

cout << ncliente[i] << ": ";
for(j = 0; j < 5; j++){
if(kilogramos[j] > 13000){
cout << alimentos[j] << " ";
}
}
cout << endl;

for(l = 0; l < 5; l++){
kilogramos[l] = 0;
}
}
    
    //punto 2: 
    int count = 13000; 

    for (int i = 0; i > count; i++)
    {
        
    }
    
    int cantentregas = 0;   
    return 0; 
}